package com.feifei.yichuan;


/**
 * ���������� ���
 * @author yanpf
 * @date 2018��7��30�� ����6:30:21
 * @description
 * @example
 *
 * @Solution
 */
public class TSP {
	
	public static void main(String[] args) {
		int numCities = 100;
		City[] cities = new City[numCities];
		
		for(int i=0; i<numCities; i++) {
			int x = (int) (Math.random() * 100);
			int y = (int) (Math.random() * 100);
			cities[i] = new City(x, y);
		}
		
		GeneticAlgorithm ge = new GeneticAlgorithm(100, 0.001, 0.9, 2, 5);
		Population population = ge.initPopulation(cities.length);
		population = ge.crossoverPopulation(population);
		ge.evalPopulation(population, cities);
		int generation = 0;
		
		while(!ge.isTerminationConditionMet(generation, 10000000)) {
			
			Route route = new Route(population.getFitnessest(0), cities);
			System.out.println("best solution: " + route.getDistance());
			System.out.println("best individual: " + population.getFitnessest(0).toString());
			
			//����
			population = ge.crossoverPopulation(population);
			
			//����
			population = ge.mutatePopulation(population);
			
			//����
			ge.evalPopulation(population, cities);
			generation ++;
			
		}
		
		Route route = new Route(population.getFitnessest(0), cities);
		System.out.println("best solution after : " + generation + " generations " + route.getDistance());
		System.out.println("best individual: " + population.getFitnessest(0).toString());
	}

}
