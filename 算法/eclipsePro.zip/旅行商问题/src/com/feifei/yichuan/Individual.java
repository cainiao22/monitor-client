package com.feifei.yichuan;

/**
 * 
 * @author yanpf
 * @date 2018��7��24�� ����5:55:14
 * @description  ����
 * @example
 *
 * @Solution
 */
public class Individual {
	
	private int[] chromosome;
	
	private double fitness = -1;

	public Individual(int[] chromosome) {
		this.chromosome = chromosome;
	}
	
	public Individual(int chromosomeLength) {
		this.chromosome = new int[chromosomeLength];
		for(int i=0; i<chromosomeLength; i++) {
			chromosome[i] = i;
		}
	}
	
	public void setGene(int offset, int gene) {
		this.chromosome[offset] = gene;
	}
	
	public int getGene(int offset) {
		return chromosome[offset];
	}

	public int[] getChromosome() {
		return chromosome;
	}

	public void setChromosome(int[] chromosome) {
		this.chromosome = chromosome;
	}

	public int getChromosomeLength() {
		return chromosome.length;
	}
	
	public double getFitness() {
		return fitness;
	}

	public void setFitness(double fitness) {
		this.fitness = fitness;
	}
	
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		for(int i=0; i<chromosome.length; i++) {
			sb.append(chromosome[i] + " ");
		}
		return sb.toString();
	}
	
}
