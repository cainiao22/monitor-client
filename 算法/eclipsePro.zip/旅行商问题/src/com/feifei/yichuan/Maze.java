package com.feifei.yichuan;

import java.util.List;

public class Maze {
	
	/**
	 * û�п��ߵ�·����
	 */
	public static final int EMPTY = 0;
	public static final int WALL = 1;
	public static final int START = 2;
	public static final int ROUTE = 3;
	public static final int GOAL = 4;
	
	private int[][] maze;
	
	private int[] startPosition = {-1, -1};
	
	public Maze(int[][] maze) {
		this.maze = maze;
	}
	
	public int[] getStartPosition() {
		if(startPosition[0] != -1 && startPosition[1] != -1) {
			return startPosition;
		}
		
		int[] startPosition = {0, 0};
		
		for(int i=0; i<maze.length; i++) {
			for(int j=0; j<maze[0].length; j++) {
				if(maze[i][j] == 2) {
					this.startPosition = new int[] {i, j};
					return this.startPosition;
				}
			}
		}
	
		return startPosition;
	}
	
	public int getPositionValue(int x, int y) {
		if(x < 0 || y < 0 || x >= maze.length || y >= maze[0].length ) {
			return WALL;
		}
		
		return maze[x][y];
	}
	
	public boolean isWall(int x, int y) {
		return getPositionValue(x, y) == 1;
	}
	
	public int getMaxX() {
		return maze.length - 1;
	}
	
	public int getMaxY() {
		return maze[0].length - 1;
	}
	
	public int scoreRoute(List<int[]> stepList) {
		boolean[][] visited = new boolean[getMaxX() + 1][getMaxY() + 1];
		int score = 0;
		for(int[] step : stepList) {
			if(maze[step[0]][step[1]] == ROUTE && !visited[step[0]][step[1]]) {
				score += 1;
				visited[step[0]][step[1]] = true;
			}
		}
		
		return score;
	}
	
	
}
