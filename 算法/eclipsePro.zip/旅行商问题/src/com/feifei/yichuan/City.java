package com.feifei.yichuan;

public class City {
	
	private int x;
	private int y;
	
	public City(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}
	
	public double distanceFrom(City other) {
		double deltaXsq = Math.pow(this.x - other.x, 2);
		double deltaYsq = Math.pow(this.y - other.y, 2);
		
		double distance = Math.sqrt(deltaXsq + deltaYsq);
		
		return distance;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

}
