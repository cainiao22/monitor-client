package com.feifei.yichuan;

/**
 * 
 * @author yanpf
 * @date 2018��7��31�� ����10:10:14
 * @description
 * @example
 *
 * @Solution
 */
public class Route {
	
	private City[] route;
	
	private double distance = 0;
	
	public Route(Individual individual, City[] cities) {
		this.route = new City[individual.getChromosomeLength()];
		int[] chromosome = individual.getChromosome();
		for(int i=0; i<individual.getChromosomeLength(); i++) {
			route[i] = cities[chromosome[i]];
		}
	}
	
	public double getDistance() {
		if(distance > 0) {
			return distance;
		}
		
		double totalDistance = 0;
		for(int i=0; i<this.route.length; i++) {
			totalDistance += this.route[i].distanceFrom(route[(i+1)%route.length]);
		}
		
		this.distance = totalDistance;
		
		return totalDistance;
	}

}
