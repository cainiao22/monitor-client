package com.feifei.yichuan;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author yanpf
 * @date 2018��7��27�� ����2:44:15
 * @description
 * @example
 *
 * @Solution
 */
public class Robot {
	
	private enum Direction {NORTH,EAST, SOUTH, WEST};
	
	private enum Action {NONE, FRONT, LEFT, RIGHT}
	
	private int xPosition;
	
	private int yPosition;
	
	private Direction head;
	
	int maxMoves;
	
	int moves;
	
	private int sensorVal;
	
	private int[] senserActions;
	
	private Maze maze;
	
	private List<int[]> routeList;
	
	
	public Robot(int[] sensorActionsStr, Maze maze, int maxMoves) {
		this.senserActions = this.calSensorActions(sensorActionsStr);
		this.maze = maze;
		int[] startPosition = maze.getStartPosition();
		this.xPosition = startPosition[0];
		this.yPosition = startPosition[1];
		
		this.sensorVal = -1;
		
		this.head = Direction.EAST;
		
		this.maxMoves = maxMoves;
		this.moves = 0;
		
		this.routeList = new ArrayList<>();
		this.routeList.add(startPosition);
	}
	
	public void run() {
		while(true) {
			moves ++;
			if (getNextAction() == Action.NONE) {
				return;
			}
			
			if(this.maze.getPositionValue(xPosition, yPosition) == Maze.GOAL) {
				return;
			}
			
			if(this.moves > maxMoves) {
				return;
			}
			
			this.makeNextAction();
		}
	}
	
	//�ķ����ǰ��մ���������������һ������Ч�Ķ�������ȥӦ�Բ�ͬ�����������
	private int[] calSensorActions(int[] sensorActionsStr) {
		int numSensorActions = sensorActionsStr.length / 2;
		int[] sensorActions = new int[numSensorActions];
		
		for(int sensorValue = 0; sensorValue < numSensorActions; sensorValue ++) {
			int sensorAction = 0;
			if(sensorActionsStr[sensorValue * 2] == 1) {
				sensorAction += 2;
			}
			
			if(sensorActionsStr[sensorValue * 2 + 1] == 1) {
				sensorAction += 1;
			}
			
			sensorActions[sensorValue] = sensorAction;
		}
		
		return sensorActions;
		
	}
	
	public void makeNextAction() {
		//��ǰ�ƶ�
		if(this.getNextAction() == Action.FRONT) {
			int currentX = this.xPosition;
			int currentY = this.yPosition;
			
			if(Direction.NORTH == this.head) {
				this.yPosition -= 1;
				if(this.yPosition < 0) {
					this.yPosition = 0;
				}
			}
			if(Direction.SOUTH == this.head) {
				this.yPosition += 1;
				if(this.yPosition > this.maze.getMaxY()) {
					this.yPosition = this.maze.getMaxY();
				}
			}
			
			if (Direction.EAST == this.head) {
				this.xPosition += 1;
				if(this.xPosition > this.maze.getMaxX()) {
					this.xPosition = this.maze.getMaxX();
				}
			}
			
			if (Direction.WEST == this.head) {
				this.xPosition -= 1;
				if(this.xPosition < 0) {
					this.xPosition = 0;
				}
			}
			
			if(this.maze.isWall(xPosition, yPosition)) {
				xPosition = currentX;
				yPosition = currentY;
			}
			
			if(this.xPosition != currentX || this.yPosition != currentY) {
				this.routeList.add(this.getPosition());
			}
		}else if (Action.LEFT == this.getNextAction()) {
			if(this.head == Direction.NORTH) {
				this.head = Direction.WEST;
			}else if(this.head == Direction.SOUTH) {
				this.head = Direction.EAST;
			}else if(this.head == Direction.EAST) {
				this.head = Direction.NORTH;
			}else if(this.head == Direction.WEST) {
				this.head = Direction.SOUTH;
			}
		}else if (Action.RIGHT == this.getNextAction()) {
			if(this.head == Direction.NORTH) {
				this.head = Direction.EAST;
			}else if(this.head == Direction.SOUTH) {
				this.head = Direction.WEST;
			}else if(this.head == Direction.EAST) {
				this.head = Direction.SOUTH;
			}else if(this.head == Direction.WEST) {
				this.head = Direction.NORTH;
			}
		}
		
		this.sensorVal = -1;
	}
	
	public Action getNextAction() {
		return Action.values()[this.senserActions[getSensorValue()]];
	}
	
	public int getSensorValue() {
		if(this.sensorVal > -1) {
			return this.sensorVal;
		}
		
		boolean frontSensor = false, frontLeftSensor = false, frontRightSensor = false;
		boolean leftSensor = false, rightSensor = false, backSensor = false;
		
		if(this.head == Direction.NORTH) {
			frontSensor = maze.isWall(xPosition, yPosition - 1);
			frontLeftSensor = maze.isWall(xPosition - 1,  yPosition - 1);
			frontRightSensor = maze.isWall(xPosition + 1, yPosition - 1);
			
			leftSensor = maze.isWall(xPosition - 1, yPosition);
			rightSensor = maze.isWall(xPosition + 1,  yPosition);
			backSensor = maze.isWall(xPosition, yPosition + 1);
		}else if(this.head == Direction.EAST) {
			frontSensor = maze.isWall(xPosition + 1, yPosition);
			frontLeftSensor = maze.isWall(xPosition + 1,  yPosition - 1);
			frontRightSensor = maze.isWall(xPosition + 1, yPosition + 1);
			
			leftSensor = maze.isWall(xPosition, yPosition - 1);
			rightSensor = maze.isWall(xPosition,  yPosition + 1);
			backSensor = maze.isWall(xPosition - 1, yPosition);
		}else if(this.head == Direction.WEST) {
			frontSensor = maze.isWall(xPosition - 1, yPosition);
			frontLeftSensor = maze.isWall(xPosition - 1,  yPosition - 1);
			frontRightSensor = maze.isWall(xPosition - 1, yPosition + 1);
			
			leftSensor = maze.isWall(xPosition, yPosition + 1);
			rightSensor = maze.isWall(xPosition,  yPosition - 1);
			backSensor = maze.isWall(xPosition + 1, yPosition);
		}else if(this.head == Direction.SOUTH) {
			frontSensor = maze.isWall(xPosition, yPosition + 1);
			frontLeftSensor = maze.isWall(xPosition - 1,  yPosition + 1);
			frontRightSensor = maze.isWall(xPosition + 1, yPosition + 1);
			
			leftSensor = maze.isWall(xPosition + 1, yPosition);
			rightSensor = maze.isWall(xPosition - 1,  yPosition);
			backSensor = maze.isWall(xPosition, yPosition - 1);
		}
		
		int sensorVal = 0;
		if(frontSensor) {
			sensorVal += 1;
		}
		if(frontLeftSensor) {
			sensorVal += 2;
		}
		if(frontRightSensor) {
			sensorVal += 4;
		}
		if(leftSensor) {
			sensorVal += 8;
		}
		if(rightSensor) {
			sensorVal += 16;
		}
		if(backSensor) {
			sensorVal += 32;
		}
		
		this.sensorVal = sensorVal;
		
		return sensorVal;
	}
	
	public int[] getPosition() {
		return new int[] {xPosition, yPosition};
	}

	public List<int[]> getRouteList() {
		return routeList;
	}

	public void setRouteList(List<int[]> routeList) {
		this.routeList = routeList;
	}
	
	
}
