package com.feifei.yichuan;

/**
 * 
 * @author yanpf
 * @date 2018��7��24�� ����5:46:01
 * @description
 * @example
 *
 * @Solution
 */
public class AllOnesGA {
	
	public static void main(String[] args) {
		GeneticAlgorithm geneticAlgorithm = new GeneticAlgorithm(100, 0.01, 0.95, 2);
		Population population = geneticAlgorithm.initPopulation(50);
		
		geneticAlgorithm.evalPopulation(population);
		
		int generation = 1;
		
		while(!geneticAlgorithm.isTerminationConditionMet(population)) {
			Individual individual = population.getFitnessest(0);
			System.out.println("best solution: " + individual.getFitness());
			System.out.println("best individual: " + individual.toString());
			population = geneticAlgorithm.crossoverPopulation(population);
			population = geneticAlgorithm.mutatePopulation(population);
			geneticAlgorithm.evalPopulation(population);
			generation ++;
		}
		
		System.out.println("found solution in " + generation + " genetations");
		System.out.println("best generation is : " + population.getFitnessest(0) );
	}

}
