package com.feifei.yichuan;

import java.util.Random;

/**
 * 
 * @author yanpf
 * @date 2018��7��24�� ����1:33:15
 * @description
 * @example
 *
 * @Solution
 */
public class GeneticAlgorithm {
	
	//��Ⱥ��ģ
	private int populationSize;
	
	//������
	private double mutationRate;
	
	
	//������
	private double crossoverRate;
	
	//��Ӣ����
	private int elitismCount;

	public GeneticAlgorithm(int populationSize, double mutationRate, double crossoverRate, int elitismCount) {
		super();
		this.populationSize = populationSize;
		this.mutationRate = mutationRate;
		this.crossoverRate = crossoverRate;
		this.elitismCount = elitismCount;
	}
	
	public Population initPopulation(int chromosome) {
		Population population = new Population(populationSize, chromosome);
		return population;
	}
	
	/**
	 * ����������Ӧ��
	 * @param individual
	 * @return
	 */
	public double calFitness(Individual individual) {
		double sum = 0;
		for(int i=0; i<individual.getChromosomeLength(); i++) {
			if(individual.getChromosome()[i] == 1) {
				sum += 1;
			}
		}
		
		double fitness = sum/individual.getChromosomeLength();
		individual.setFitness(fitness);
		return fitness;
	}
	
	/**
	 * ����������Ⱥ����Ӧ��
	 * @param population
	 */
	public void evalPopulation(Population population) {
		double fitness = 0;
		for(int i=0; i<population.size(); i++) {
			fitness += calFitness(population.getIndividual(i));
		}
		
		population.setPopulationFitness(fitness);
	}
	
	public boolean isTerminationConditionMet(Population population) {
		for(int i=0; i<population.size(); i++) {
			if(population.getIndividual(i).getFitness() == 1) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * ���̶� ѡ�񽻲���
	 * @param population
	 * @return
	 */
	public Individual selectParent(Population population) {
		double populationFittness = population.getPopulationFitness();
		double rouletteWheelPosition = Math.random() * populationFittness;
		double spinWheel = 0;
		for(int i=0; i<population.size(); i++) {
			Individual individual = population.getIndividual(i);
			spinWheel += individual.getFitness();
			if(spinWheel >= rouletteWheelPosition) {
				return individual;
			}
		}
		
		return population.getIndividual(population.size() - 1);
	}

	/**
	 * �������
	 * @param population
	 */
	public Population crossoverPopulation(Population population) {
		Population newPopulation = new Population(population.size());
		for(int i=0; i<population.size(); i++) {
			Individual parent1 = population.getFitnessest(i);
			if(this.elitismCount < i && crossoverRate > Math.random()) {
				Individual offSpring = new Individual(parent1.getChromosomeLength());
				Individual parent2 = selectParent(population);
				for(int offset = 0; offset < parent1.getChromosomeLength(); offset ++) {
					if(Math.random() > 0.5) {
						offSpring.setGene(offset, parent1.getGene(offset));
					}else {
						offSpring.setGene(offset, parent2.getGene(offset));
					}
				}
				newPopulation.setIndividual(offSpring, i);
			}else {
				newPopulation.setIndividual(parent1, i);
			}
		}
		
		return newPopulation;
		
	}
	
	public Population mutatePopulation(Population population) {
		Population newPopulation = new Population(population.size());
		for(int i=0; i<population.size(); i++) {
			Individual individual = population.getFitnessest(i);
			if(i >= this.elitismCount) {
				for(int genIndex=0; genIndex < individual.getChromosomeLength(); genIndex ++) {
					if(this.mutationRate > Math.random()) {
						individual.setGene(genIndex, 1 - individual.getGene(genIndex));
					}
				}
			}
			
			newPopulation.setIndividual(individual, i);
		}
		
		return newPopulation;
	}

}
