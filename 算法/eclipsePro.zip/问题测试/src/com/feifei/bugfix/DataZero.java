package com.feifei.bugfix;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;

public class DataZero {

	static DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	public static void main(String[] args) throws Exception {
		String value = "1970-01-01 00:00:00";
		LocalDateTime localDateTime = LocalDateTime.from(timestampFormat(3).parse(value));
		ZoneId zoneOffset = ZoneOffset.systemDefault();
		long result = localDateTime.atZone(zoneOffset).toEpochSecond();
		//Timestamp.valueOf(dateTime)
		System.out.println(Timestamp.from(Instant.EPOCH).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime().atZone(zoneOffset).toEpochSecond());
	}
	
	private static DateTimeFormatter timestampFormat(int length) {
        final DateTimeFormatterBuilder dtf = new DateTimeFormatterBuilder()
                .appendPattern("yyyy-MM-dd HH:mm:ss");
        if (length > 0) {
            dtf.appendFraction(ChronoField.MICRO_OF_SECOND, 0, length, true);
        }
        return dtf.toFormatter().withZone(ZoneOffset.UTC);
    }

}
