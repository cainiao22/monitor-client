package compile.lesson2.lexer;

public interface Tag {
	int NUM = 256, ID = 257, TRUE = 258, FALSE = 259;
}
