package compile.lesson2.lexer;

public class Token {
	
	public final int tag;

	public Token(int tag) {
		super();
		this.tag = tag;
	}
	
}
