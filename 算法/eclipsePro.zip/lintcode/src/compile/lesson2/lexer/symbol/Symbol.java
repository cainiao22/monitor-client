package compile.lesson2.lexer.symbol;

public class Symbol {

}
