package com.feifei.yichuan;

import java.util.Random;

public class RobotController {
	
	public static int maxGenerations = 10000;
	
	
	public static void main(String[] args) {
		
		Random random = new Random();
		int[][] map = new int[9][9];
		for(int i=0; i<map.length; i++) {
			for(int j = 0; j< map[0].length; j++) {
				map[i][j] = random.nextInt(4);
			}
		}
		
		int count = 0;
		for(int i=0; i<map.length; i++) {
			for(int j=0; j<map[0].length; j++) {
				System.out.print(map[i][j] + " ");
				if (map[i][j] == Maze.ROUTE) {
					count ++;
				}
			}
			System.out.println();
		}
		
		Maze maze = new Maze(map);
		
		
		GeneticAlgorithm ga = new GeneticAlgorithm(200, 0.05, 0.9, 10, 20);
		
		Population population = ga.initPopulation(128);
		
		ga.evalPopulation(population, maze);
		int generationCount = 1;
		while(!ga.isTerminationConditionMet(generationCount, maxGenerations)) {
			Individual individual = population.getFitnessest(0);
			System.out.println("best solution: " + individual.getFitness());
			System.out.println("best individual: " + individual.toString());
			
			
			//����
		    population = ga.crossoverPopulationDanDianJiaoCha(population);
			
			//����
			population = ga.mutatePopulation(population);
			
			ga.evalPopulation(population, maze);
			generationCount ++;
		}
		
		System.out.println("found solution in " + generationCount + " genetations");
		System.out.println("best generation is : " + population.getFitnessest(0) );
		System.out.println("road count : " + count );
	}
	

}
