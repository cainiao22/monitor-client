package com.feifei.yichuan;

/**
 * 
 * @author yanpf
 * @date 2018��7��31�� ����3:49:40
 * @description  ѧ��������Ϣ
 * @example
 *
 * @Solution
 */
public class Group {
	
	private final int groupId;
	
	private final int groupSize;
	
	private final int[] moduleIds;

	public Group(int groupId, int groupSize, int[] moduleIds) {
		super();
		this.groupId = groupId;
		this.groupSize = groupSize;
		this.moduleIds = moduleIds;
	}

	public int getGroupId() {
		return groupId;
	}

	public int getGroupSize() {
		return groupSize;
	}

	public int[] getModuleIds() {
		return moduleIds;
	}

}
