package com.feifei.yichuan;

public class Class {
	
	private final int classId;
	
	private final int groupId;
	
	private final int moduleId;
	
	private int professorId;
	
	private int timeslotId;
	
	private int roomId;

	public Class(int classId, int groupId, int moduleId) {
		super();
		this.classId = classId;
		this.groupId = groupId;
		this.moduleId = moduleId;
	}

	public int getProfessorId() {
		return professorId;
	}

	public void setProfessorId(int professorId) {
		this.professorId = professorId;
	}

	public int getTimeslotId() {
		return timeslotId;
	}

	public void setTimeslotId(int timeslotId) {
		this.timeslotId = timeslotId;
	}

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public int getClassId() {
		return classId;
	}

	public int getGroupId() {
		return groupId;
	}

	public int getModuleId() {
		return moduleId;
	}
}
