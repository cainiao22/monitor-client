package com.feifei.yichuan;

public class TimeTableGA {
	
	public static void main(String[] args) {
		TimeTable timeTable = initTimeTable();
		GeneticAlgorithm ge = new GeneticAlgorithm(100, 0.01, 0.95, 2, 5);
		Population population = ge.initPopulation(timeTable);
		ge.evalPopulation(population, timeTable);
		int generation = 0;
		while(!ge.isTerminationConditionMet(population)) {
			System.out.println("best solution: " + population.getFitnessest(0).getFitness());
			System.out.println("best individual: " + population.getFitnessest(0).toString());
			
			population = ge.crossoverPopulationDanDianJiaoCha(population);
			
			population = ge.mutatePopulation(population, timeTable);
			
			ge.evalPopulation(population, timeTable);
			generation ++;
		}
		
		System.out.println("found solution after " + generation + "generations");
		System.out.println(population.getFitnessest(0));
	}
	
	private static TimeTable initTimeTable() {
		
		TimeTable timeTable = new TimeTable();
		timeTable.addRoom(1, "A1", 15);
		timeTable.addRoom(2, "B1", 30);
		timeTable.addRoom(3, "C1", 10);
		timeTable.addRoom(4, "D1", 20);
		timeTable.addRoom(5, "F1", 25);
		
		timeTable.addTimeslot(1, "Mon 9:00 - 11:00");
		timeTable.addTimeslot(2, "Mon 11:00 - 13:00");
		timeTable.addTimeslot(3, "Mon 13:00 - 15:00");
		
		timeTable.addTimeslot(4, "Tue 9:00 - 11:00");
		timeTable.addTimeslot(5, "Tue 11:00 - 13:00");
		timeTable.addTimeslot(6, "Tue 13:00 - 15:00");
		
		timeTable.addTimeslot(7, "Wen 9:00 - 11:00");
		timeTable.addTimeslot(8, "Wen 11:00 - 13:00");
		timeTable.addTimeslot(9, "Wen 13:00 - 15:00");
		
		timeTable.addTimeslot(10, "Thu 9:00 - 11:00");
		timeTable.addTimeslot(11, "Thu 11:00 - 13:00");
		timeTable.addTimeslot(12, "Thu 13:00 - 15:00");
		
		timeTable.addTimeslot(13, "Fri 9:00 - 11:00");
		timeTable.addTimeslot(14, "Fri 11:00 - 13:00");
		timeTable.addTimeslot(15, "Fri 13:00 - 15:00");
		
		
		timeTable.addProfessor(1, "Dr R");
		timeTable.addProfessor(2, "Mis A");
		timeTable.addProfessor(3, "Dr P");
		timeTable.addProfessor(4, "Mis E");
		
		
		timeTable.addModule(1, "cs1", "computer science", new int[] {1, 2});
		timeTable.addModule(2, "en1", "English", new int[] {1, 3});
		timeTable.addModule(3, "ma1", "Maths", new int[] {1, 2});
		timeTable.addModule(4, "ph1", "Physics", new int[] {3, 4});
		timeTable.addModule(5, "hi1", "History", new int[] {4});
		timeTable.addModule(6, "dr1", "Drama", new int[] {1, 4});
		
		
		timeTable.addGroup(1, 10, new int[] {1, 3, 4});
		timeTable.addGroup(2, 30, new int[] {2, 3, 5, 6});
		timeTable.addGroup(3, 18, new int[] {3, 4, 5});
		timeTable.addGroup(4, 25, new int[] {1, 4});
		timeTable.addGroup(5, 20, new int[] {2, 3, 5});
		timeTable.addGroup(6, 22, new int[] {1, 4, 5});
		timeTable.addGroup(7, 16, new int[] {1, 3});
		timeTable.addGroup(8, 18, new int[] {2, 6});
		timeTable.addGroup(9, 24, new int[] {1, 6});
		timeTable.addGroup(10, 25, new int[] {3, 4});
		
		return timeTable;
		
	}

}
