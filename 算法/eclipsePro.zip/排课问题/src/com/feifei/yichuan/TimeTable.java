package com.feifei.yichuan;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TimeTable {
	
	private Map<Integer, Room> rooms;
	
	private Map<Integer, Module> modules;
	
	private Map<Integer, Group> groups;
	
	private Map<Integer, Professor> professors;
	
	private Map<Integer, Timeslot> timeslots;
	
	private Class[] classes;
	
	private int numClasses = 0;
	
	public TimeTable() {
		rooms = new HashMap<>();
		modules = new HashMap<>();
		groups = new HashMap<>();
		professors = new HashMap<>();
		timeslots = new HashMap<>();
	}
	
	public TimeTable(TimeTable cloneable) {
		rooms = cloneable.rooms;
		modules = cloneable.modules;
		groups = cloneable.groups;
		professors = cloneable.professors;
		timeslots = cloneable.timeslots;
		classes = cloneable.classes;
	}

	public Map<Integer, Room> getRooms() {
		return rooms;
	}

	public void setRooms(Map<Integer, Room> rooms) {
		this.rooms = rooms;
	}

	public Map<Integer, Module> getModules() {
		return modules;
	}

	public void setModules(Map<Integer, Module> modules) {
		this.modules = modules;
	}

	public Map<Integer, Group> getGroups() {
		return groups;
	}

	public void setGroups(Map<Integer, Group> groups) {
		this.groups = groups;
	}

	public Map<Integer, Professor> getProfessors() {
		return professors;
	}

	public void setProfessors(Map<Integer, Professor> professors) {
		this.professors = professors;
	}

	public Map<Integer, Timeslot> getTimeslots() {
		return timeslots;
	}

	public void setTimeslots(Map<Integer, Timeslot> timeslots) {
		this.timeslots = timeslots;
	}

	public Class[] getClasses() {
		return classes;
	}

	public void setClasses(Class[] classes) {
		this.classes = classes;
	}

	public int getNumClasses() {
		if(numClasses > 0) {
			return numClasses;
		}
		Group[] groups = this.getGroupsAsArray();
		for(Group group : groups) {
			this.numClasses += group.getModuleIds().length;
		}
		
		return this.numClasses;
	}

	public void setNumClasses(int numClasses) {
		this.numClasses = numClasses;
	}
	
	public void addRoom(int roomId, String roomNum, int capacity) {
		this.rooms.put(roomId, new Room(roomId, roomNum, capacity));
	}
	
	public void addProfessor(int professorId, String professorName) {
		this.professors.put(professorId, new Professor(professorId, professorName));
	}
	
	public void addModule(int moduleId, String moduleCode, String module, int[] professorIds) {
		this.modules.put(moduleId, new Module(moduleId, moduleCode, module, professorIds));
	}
	
	public void addGroup(int groupId, int groupSize, int[] moduleIds) {
		this.groups.put(groupId, new Group(groupId, groupSize, moduleIds));
	}
	
	public void addTimeslot(int timeslotId, String timeslot) {
		this.timeslots.put(timeslotId, new Timeslot(timeslotId, timeslot));
	}
	
	public void createClasses(Individual individual) {
		Class[] classes = new Class[this.getNumClasses()];
		int[] chromosome = individual.getChromosome();
		int chromosomeIndex = 0;
		int classIndex = 0;
		
		for(Group group : this.getGroupsAsArray()) {
			int[] moduleIds = group.getModuleIds();
			for(int moduleId : moduleIds) {
				classes[classIndex] = new Class(classIndex, group.getGroupId(), moduleId);
				classes[classIndex].setTimeslotId(chromosome[chromosomeIndex]);
				chromosomeIndex ++;
				classes[classIndex].setRoomId(chromosome[chromosomeIndex]);
				chromosomeIndex ++;
				classes[classIndex].setProfessorId(chromosome[chromosomeIndex]);
				chromosomeIndex ++;
				
				classIndex ++;
			}
		}
		
		this.classes = classes;
	}
	
	
	public Room getRoom(int roomId) {
		if(!this.rooms.containsKey(roomId)) {
			System.out.println("û�и�room�� " + roomId);
		}
		
		return rooms.get(roomId);
	}
	
	public Room getRandomRoom() {
		Object[] rooms = this.rooms.values().toArray();
		return (Room) rooms[(int) (Math.random() * rooms.length)];
	}
	
	public Professor getPrefessor(int prefessorId) {
		return this.professors.get(prefessorId);
	}
	
	public Module getModule(int moduleId) {
		return this.modules.get(moduleId);
	}
	
	public int[] getGroupModules(int groupId) {
		return this.groups.get(groupId).getModuleIds();
	}
	
	public Group getGroup(int groupId) {
		return this.groups.get(groupId);
	}
	
	public Group[] getGroupsAsArray() {
		return groups.values().toArray(new Group[groups.size()]);
	}
	
	public Timeslot geTimeslot(int timeslotId) {
		return this.timeslots.get(timeslotId);
	}
	
	public Timeslot getRandomTimeslot() {
		Object[] timeslots = this.timeslots.values().toArray();
		return (Timeslot) timeslots[(int) (Math.random() * timeslots.length)];
	}
	
	public int calcClashes() {
		int clashes = 0;
		for(Class clazz : classes) {
			int capacity = this.getRoom(clazz.getRoomId()).getCapacity();
			int groupSize = this.getGroup(clazz.getGroupId()).getGroupSize();
			if(capacity < groupSize) {
				clashes ++;
			}
			
			for(Class clazzB : classes) {
				if(clazz.getClassId() == clazzB.getClassId()) {
					continue;
				}
				if(clazz.getTimeslotId() == clazzB.getTimeslotId() 
						&& clazz.getRoomId() == clazzB.getRoomId()) {
					clashes ++;
					
					if(clazzB.getProfessorId() == clazz.getProfessorId()) {
						clashes ++;
					}
				}
	
			}
		}
		
		return clashes;
	}
	
	

}
