package com.feifei.yichuan;

public class Timeslot {
	
	private final int timeslotId;
	
	private final String timeslot;

	public Timeslot(int timeslotId, String timeslot) {
		super();
		this.timeslotId = timeslotId;
		this.timeslot = timeslot;
	}

	public int getTimeslotId() {
		return timeslotId;
	}

	public String getTimeslot() {
		return timeslot;
	}

}
