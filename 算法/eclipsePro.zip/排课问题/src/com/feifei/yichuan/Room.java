package com.feifei.yichuan;

public class Room {
	
	private int roomId;
	
	private String roomNum;
	
	private int capacity;

	public Room(int roomId, String roomNum, int capacity) {
		super();
		this.roomId = roomId;
		this.roomNum = roomNum;
		this.capacity = capacity;
	}

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public String getRoomNum() {
		return roomNum;
	}

	public void setRoomNum(String roomNum) {
		this.roomNum = roomNum;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
	

}
