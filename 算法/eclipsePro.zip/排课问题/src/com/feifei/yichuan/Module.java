package com.feifei.yichuan;


/**
 * 
 * @author yanpf
 * @date 2018��7��31�� ����3:49:04
 * 
 * @description ���ڿγ�ѧϰ��Ԫ����Ϣ
 * @example
 *
 * @Solution
 */
public class Module {
	
	private final int moduleId;
	
	private final String moduleCode;
	
	private final String module;
	
	private final int[] professorIds;

	public Module(int moduleId, String moduleCode, String module, int[] professorIds) {
		super();
		this.moduleId = moduleId;
		this.moduleCode = moduleCode;
		this.module = module;
		this.professorIds = professorIds;
	}
	
	public int getModuleId() {
		return moduleId;
	}



	public String getModuleCode() {
		return moduleCode;
	}



	public String getModule() {
		return module;
	}



	public int[] getProfessorIds() {
		return professorIds;
	}



	public int getRandomProfessorId() {
		int professorId = professorIds[(int) (Math.random()*professorIds.length)];
		return professorId;
	}

}
