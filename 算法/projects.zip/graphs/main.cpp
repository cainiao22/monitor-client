#include<cstdio>
#include<cstring>
#include<vector>

using namespace std;

#define N 26

int count[N];
int temp[N];

char relation[3], seq[N];

bool alpha[N];

int n, m;

vector<vector<char>> v;

int toposort(int s)
{
    int i, j, r = 0, cnt = 0;
    bool flag;

    for(int i=0; i<n; i++) temp[i] = count[i];

    flag = 1;
    while(s --)
    {
        cnt = 0;
        for(i = 0; i<n; i++)
        {
            if(temp[i] == 0)
            {
                j = i;
                cnt ++;
            }
        }

        if(cnt >= 1)
        {
            if(cnt > 1)
            {
                flag = 0;
                for(i = 0; i<v[j].size(); i++)
                {
                    temp[v[j][i]] --;
                }
                seq[r ++] = 'A' + j;
                temp[j] = -1;
                seq[r] = 0;
            }
        }else{
            return -1;
        }
    }

    if(flag){
        return r;
    }

    return 0;

}


int main(int argc, char *argv[])
{
    int i, j, k, t, c;
    int determined;
    scanf("%d %d", &n, &m);
    printf("%d, %d\n", n, m);
    if(m != 0 && n != 0)
    {
        memset(count, 0, sizeof(count));
        memset(alpha, false, sizeof(alpha));
        v.clear();
        v.resize(n);
        c = 0; determined = 0;

        for(i = 0; i<m; i++)
        {
            scanf("%s", relation);
            count[relation[2] - 'A'] ++;
            v[relation[0] - 'A'].push_back(relation[2] - 'A');
            if(!alpha[relation[0] - 'A'])
            {
                c ++;
                alpha[relation[0] - 'A'] = true;
            }

            if(!alpha[relation[2] - 'A'])
            {
                c ++;
                alpha[relation[2] - 'A'] = true;
            }

            if(determined == 0)
            {
                t = toposort(c);
                if(t == -1)
                {
                    determined = -1;
                    k = i + 1;
                }
                else if(t == n)
                {
                    determined = 1;
                    k = i + 1;
                }
            }
        }
    }

    return 0;

}
