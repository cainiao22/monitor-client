#include <cstdio>
#include <cstdlib>
#include <cstring>

#include "common.h"

using namespace std;


/**
 *
 *  匈牙利算法求解二分图的最大匹配
 *
 */

namespace hungarian_method {

//x点级的匹配
int cx[NMAX];
//y点级的匹配
int cy[NMAX];

int nx, ny;


int g[NMAX][NMAX];

//访问标识
int flag[NMAX];


int maxMatrix()
{
    memset(cx, 0, nx);
    memset(cy, 0, ny);
    int sum = 0;
    for(int u=0; u<nx; u++)
    {
        memset(flag, 0, sizeof(flag));
        if(path(u))
        {
            sum ++;
        }
    }

    return sum;
}

/**
 * @brief path dfs求解最大匹配
 *        空间复杂度低(与bfs相比)，适合稠密图
 *        时间复杂度有点高 path为O(n^2) 整体为O(n^3)
 * @param u
 * @return
 */
bool path(int u)
{
    for(int v=0; v<ny; v++)
    {
        if(g[u][v] && !flag[v])
        {
            flag[v] = 1;
            if(ny[v] == -1 || path(ny[v]))
            {
                nx[u] = v;
                ny[v] = u;
                return 1;
            }
        }
    }

    return 0;
}

/**
 * @brief maxMatrixBFS
 * @return
 */
int maxMatrixBFS()
{
    int pred[NMAX];
    int queue[NMAX];
    //访问标识
    int mk[NMAX];
    int tail = 0, cur = 0;
    memset(cx, -1, nx);
    memset(cy, -1, ny);
    for(int i=0; i<nx; i++)
    {
        if(!mk[i]) continue;
        tail = cur = 0;
        memset(pred, -2, sizeof(pred));
        for(int j=0; j<ny; j++)
        {
            if(g[i][j])
            {
                pred[j] = -1;
                queue[tail ++] = j;
            }
        }
        int y = -1;
        while(cur < tail)
        {
            y = queue[cur];
            if(cy[y] == -1) break;
            cur ++;
            //走到这里代表y被分配出去了
            for(int j=0; j<ny; j++)
            {
                //没在对列而且原来的那个x有连边
                if(pred[j] == -2 && g[cy[y]][j])
                {
                    pred[j] = y;
                    queue[tail ++] = j;
                }
            }
        }
        //没有找到合适的匹配
        if(cur == tail) continue;
        while(pred[y] > -1)
        {
            cx[cy[pred[y]]] = y;
            cy[y] = cy[pred[y]];
            y = pred[y];
        }

        cx[i] = y;
        cy[y] = i;
        res ++;
    }

    return res;

}

}
