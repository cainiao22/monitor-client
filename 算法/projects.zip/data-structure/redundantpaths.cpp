#include <cstdio>
#include <cstdlib>
#include <cstring>

#include "common.h"

using namespace std;

/**
 *
 * 多余的路  POJ3177
 *
 */

namespace redundantpaths {

//边节点
typedef struct NodeStr {
    int j;
    struct NodeStr* next;
}Node;

//顶点数量和边的数量
int n, m;

Node mem[M];
int memp;

//邻接表
Node *e[N];

//双联通分量
int w;

int belong[N];

//可达到的祖先的最小编号
int low[N], dfn[N];

//0代表未处理 1代表正在处理 2代表处理完成
int visited[N];

//
int bridge[M][2], nbridge;

void addEdge(Node* e[], int i, int j)
{
    Node* p = &mem[memp ++];
    p->j = j;
    //头插法
    p->next = e[i];
    e[i] = p;
}

/**
 * 并查集
 */
int findSet(int f[], int i)
{
    int j = i, t;
    while(j != f[j]) j = f[j];
    while(i != f[i])
    {
       t = f[i];
       f[i] = j;
       i = t;
    }

    return j;
}

/**
 * @brief UnitSet 并查集合并
 * @param f
 * @param i
 * @param j
 */
void UnitSet(int f[], int i, int j)
{
    i = findSet(f, i);
    j = findSet(f, j);
    if(i != j)
    {
        f[i] = j;
    }
}


void DFS_2conn(int i, int father, int depth, int f[])
{

    visited[i] = 1;
    low[i] = dfn[i] = depth;
    int toFather = 0;
    for(Node* p = e[i]; p; p = p->next)
    {
        int j = p->j;
        if(visited[j] == 1 && (father != j || toFather))
        {
            low[i] = MIN(low[i], dfn[j]);
        }
        else if(visited[j] == 0)
        {
            DFS_2conn(j, i, depth + 1, f);
            low[i] = MIN(low[i], low[j]);
            //如果i是关节点
            if(low[j] > dfn[i])
            {
                //合并联通分量，代表j和i全部属于他们上面的某个节点
                UnitSet(f, i, j);
            }
            else
            {
               // i节点是关节点
                bridge[nbridge][0] = i;
                bridge[nbridge ++][1] = j;
            }
        }
        //TODO 这东西有啥用？？？
        if(j == father) toFather = 1;
    }

    visited[i] = 2;
}

int DoubleConnection()
{
    int i, k, f[N], ncon = 0;
    //厉害了，还可以这样写？
    for(i=0; i<n; i++) f[i] = i, belong[i] = -1;
    clr(visited);
    nbridge = 0;
    DFS_2conn(0, -1, 1, f);
    for(i=0; i<n; i++)
    {
        int k = findSet(f, i);
        if(belong[k] == -1)
        {
            belong[k] = ncon ++;
            belong[i] = belong[k];
        }
    }

    return ncon;
}

int run()
{
    int m, n;
    while(scanf("%d,%d", &n, &m) != EOF)
    {
        int i, j;
        memp = 0;
        memset(e, 0, sizeof(e));
        //读取边的信息插入到邻接表中
        for(int k=0; k<m; k++)
        {
            scanf("%d%d", &i, &j);
            i --;
            j --;
            addEdge(e, i, j);
            addEdge(e, j, i);
        }
    }
}

}
