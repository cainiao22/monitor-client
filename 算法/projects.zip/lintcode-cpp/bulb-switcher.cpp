/**
* @projectName   lintcode-cpp

* @author        yanpf
* @date          2019-06-14
* @brief         灯泡切换器

* @description   起初这 n 个灯泡都是关闭状态。首先你把所有灯泡都打开。
*                然后，每隔一个灯泡关闭下一个灯泡。在第三回合，每隔两个灯泡转换下一个灯泡的状态（如果原先是关闭状态就打开，反之则关闭）。
*                对于第 i回合，每隔i - 1 个灯泡，转换下一个灯泡的状态。对于第 n 回合，只需要转换最后一个灯泡的状态。
*                在 n 回合之后，还有多少灯泡亮着。
*
*
* @example       样例1

*                输入：3
*                输出：1
*                解释：
*                起初，三个灯泡的状态是 [off, off, off].
*                第一回合之后，三个灯泡状态是 [on, on, on].
*                第二回合之后，三个灯泡状态是 [on, off, on].
*                第三回合之后，三个灯泡状态是 [on, off, off].

*                所以你应该返回 1, 因为只有一个灯泡是开着的。
*                样例2

*                输入：2
*                输出：1
* @solution
*/



#include "commonutils.h"

//TODO 数学问题
class BulbSwitcher : public CommonUtils
{
public:
    //笨方法 会浪费很大空间
    int bulbSwitch(int n)
    {
        vector<int> bulbs(n, 1);
        for(int i=1; i<n; i++)
        {
            for(int j=i; j<n; j += i + 1)
            {
                bulbs[j] = 1 - bulbs[j];
            }
            printVector(bulbs);
        }

        int result = 0;
        for(int i=0; i<n; i++)
        {
            result += bulbs[i];
        }

        return result;
    }

    int bulbSwitch2(int n)
    {
        int sum = 0;
        for(int i=1; i<=n; i++)
        {
            int item = 0;
            for(int j=1; j<=i/2; j++)
            {
                if(i % j == 0)
                {
                    item = 1 - item;
                }
            }

            item = 1 - item;

            sum += item;
        }

        return sum;
    }

    void run()
    {
        int result = this->bulbSwitch2(834551805);
        cout<<result;
    }
};









