/**
* @projectName   lintcode-cpp

* @author        yanpf
* @date          2019-06-28
* @brief         数 1
* @description   给出一个 非负 整数 num，对所有满足 0 ≤ i ≤ num 条件的数字 i 均需要计算其二进制表示中数字 1 的个数并以数组的形式返回
* @example
*               样例1

*               输入： 5
*               输出： [0,1,1,2,1,2]
*               解释：
*               0~5的二进制表示分别是：
*               000
*               001
*               010
*               011
*               100
*               101
*               每个数字中1的个数为： 0,1,1,2,1,2
*               样例2
*
*               输入： 3
*               输出： [0,1,1,2]
*
* @solution
*/




#include "commonutils.h"


class CountingBits : public CommonUtils
{
public:
    vector<int> countBits(int num)
    {
        //有点像记忆化存储
        vector<int> result(num + 1, 0);
        for(int i = 0; i < num; i ++)
        {
            //拿到i的最后一个0
            int temp = (i + 1) & i;
            if(temp != 0)
            {
                temp = i + 1 - temp;
                result[i+1] = result[temp] + result[i+1 - temp];
            }
            else
            {
                result[i + 1] = 1;
            }
        }

        return result;
    }

    vector<int> countBits2(int num)
    {
        vector<int> result(num + 1, 0);
        for(int i = 1; i <= num; i ++)
        {
            result[i] = result[i & (i-1)] + 1;
        }

        return result;
    }

    void run()
    {
        vector<int> result = this->countBits(6);
        printVector(result);
    }
};

