/**
* @projectName   lintcode-cpp

* @author        yanpf
* @date          2019-06-20
* @brief         奇偶链表
* @description   给定单链表，将所有奇数节点连接在一起，然后将偶数节点连接在一起。 请注意，这里我们讨论的是节点编号，而不是节点中的值
* @example       输入： 1->2->3->4->5->NULL
                 输出： 1->3->5->2->4->NULL
* @solution
*/



#include "commonutils.h"


class OddEvenLinkedList : public CommonUtils
{
public:
    ListNode* oddEvenList(ListNode * head)
    {
        if(head == NULL)
        {
            return head;
        }

        int count = 1;
        ListNode* h1 = head;
        ListNode* h2 = new ListNode(0);
        ListNode *t1 = h1, *t2 = h2;
        head = head->next;
        while(head != NULL)
        {
            count ++;
            if(count % 2 == 0)
            {
                t2->next = head;
                t2 = t2->next;
            }
            else
            {
                t1->next = head;
                t1 = t1->next;
            }
            head = head->next;
        }

        t1->next = h2->next;
        t2->next = NULL;
        return h1;

    }

    ListNode* oddEvenList2(ListNode * head)
    {
        if(head == NULL || head->next == NULL)
        {
            return head;
        }
        ListNode* odd = head, *even = head->next;
        ListNode* evenHead = head->next;
        while(even != NULL && even->next != NULL)
        {
            odd->next = even->next;
            odd = odd->next;
            even->next = odd->next;
            even = even->next;
        }

        odd->next = evenHead;
        return head;
    }

    void run()
    {
        ListNode* head = new ListNode(1);
        head->next = new ListNode(2);
        head->next->next = new ListNode(3);
        head->next->next->next = new ListNode(4);
        ListNode* result = this->oddEvenList(head);
        cout<<endl;
    }
};
