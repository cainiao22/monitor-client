/**
* @projectName   lintcode-cpp

* @author        yanpf
* @date          2019-06-27
* @brief         摘要
* @description   还记得卖火柴的小女孩的故事吗？现在，你知道了小女孩拥有的火柴数目和它们的长度，
*                请找出一种能使用全部火柴摆成一个正方形的方法。你不能掰断任何一根火柴，但可以将它们连接起来，
*                每根火柴必须使用正好一次。

                 你的输入是一个由火柴长度组成的数组，表示小女孩现在拥有的火柴。你应该输出true或false，
                 代表你能否找到一种方法使用全部火柴摆成一个正方形。


* @example       样例1：

*                输入：[1,1,2,2,2]
*                输出：true

*                说明：你可以构成一个边长为2的正方形，其中一条边使用两根长度为1的火柴。
*                样例2：

*                输入：[3,3,3,3,4]
*                输出：false

*                输出：你无法使用全部火柴摆成一个正方形。
*
* @solution      递归，各种剪枝
*/

#include "commonutils.h"

class MatchsticksToSquare : public CommonUtils
{
public:

    long square[4] = {0};

    long long sum = 0;

    bool helper(vector<int> &nums, int index, int max)
    {
        if(index >= nums.size())
        {
            return square[0] == square[1] && square[0] == square[2] && square[0] == square[3];
        }

        for(int i=0; i<4; i++)
        {
            //如果前一种处理情况和和当前相同那么就可以忽略了，长方形的情况应该是i-2
            if( i>0 && square[i]==square[i-1] ) continue;
            if(square[i] > max)
            {
                return false;
            }
            square[i] += nums[index];
            bool result = helper(nums, index + 1, max);
            square[i] -= nums[index];
            if(result)
            {
                return true;
            }
        }

        return false;
    }

    bool makesquare(vector<int> &nums)
    {
        if(nums.size() < 4)
        {
            return false;
        }
        for(int i=0; i<nums.size(); i++)
        {
            sum += nums[i];
        }
        if(sum % 4)
        {
            return false;
        }
        // If any num bigger than width, return false
        for (int num : nums) {
            if (num > sum / 4) return false;
        }
        return helper(nums, 0, sum / 4);
    }


    void run()
    {
        vector<int> nums({211559,9514615,7412176,5656677,3816020,452925,7979371,5025276,8882605,944541,9889007,2344356,7252152,749758,2311818});
        cout<< this->makesquare(nums) << endl;
    }
};


