/**
* @projectName   lintcode-cpp
*
* @brief         丑数 II

* @author        yanpf
* @date          2019-07-10 HH:mm:ss
* @description   设计一个算法，找出只含素因子2，3，5 的第 n 小的数。符合条件的数如：1, 2, 3, 4, 5, 6, 8, 9, 10, 12...
*                要求时间复杂度为 O(nlogn) 或者 O(n)
*
* @example       样例 1：
                   输入：9
                   输出：10

                 样例 2：
                   输入：1
                   输出：1
*
* @solution
*/


#include "commonutils.h"
//TODO 丑数 II
class UglyNumberII : public CommonUtils
{
public:
    int nthUglyNumber(int n)
    {

    }

    void run()
    {

    }
};

