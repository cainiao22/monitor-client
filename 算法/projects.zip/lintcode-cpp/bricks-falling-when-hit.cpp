/**
* @projectName   lintcode-cpp

* @author        yanpf
* @date          2019-05-28
* @brief         打砖块
* @description   有一个由 1 和 0 组成的网格: 单元格中的 1 表示砖块. 当且仅当一个砖块直接连接到网格底部, 或者其四周相邻的砖块至少有一个不会掉落时, 这个砖块不会掉落.

                 我们将按顺序进行一些消除. 每次会指定一个位置 (i, j), 消除该位置上的砖块, 然后可能会有一些砖块因这次消除操作而掉落.

                 返回一个数组, 表示每次消除后会有多少砖块掉落.

                 网格的行列数在 [1, 200] 的范围内.
                 每次消除的位置不重复, 并且一定在网格范围内.
                 如果要消除的位置没有砖块, 那么什么都不会发生.
                 行下标越小则越低, 也就是说, 行下标为 0 的位置连接着网格底部.

* @example       样例 1:

                 输入: grid = [[1,0,0,0],[1,1,1,0]], hits = [[1,0]]
                 输出: [2]
                 解释: 消除 (1, 0) 处的砖块时, 位于 (1, 1) 和 (1, 2) 的砖块会掉落, 所以返回 2.
                 样例 2:

                 输入: grid = [[1,0,0,0],[1,1,0,0]], hits = [[1,1],[1,0]]
                 输出: [0,0]
                 解释: 当我们消除 (1, 0) 的砖块时, (1, 1) 的砖块已经在前一次操作中被消除了.
                 样例 3:

                 输入: grid = [[1],[1],[1]], hits = [[0,0],[0,0]]
                 输出: [2,0]
                 解释: 第一次消除 (0, 0) 时, 另外两个砖块都掉落了. 第二次尝试消除 (0, 0) 时, 已经没有砖块了.
* @solution
*/



#include "commonutils.h"


class BricksFallingWhenHit : public CommonUtils
{
public:

    int dx[4] = {-1, 0, 1, 0};
    int dy[4] = {0, 1, 0, -1};
    int nums = 0;
    vector<vector<bool>> cache;
    
    bool vaildateGrid(int x, int y, vector<vector<int>> &grid)
    {
        if(grid[x][y] == 0)
        {
            return true;
        }
        if(x == 0)
        {
            return false;
        }
        grid[x][y] = 0;
        for(int i=0; i<4; i++)
        {
            if(x + dx[i] >= 0 && x + dx[i] < grid.size() && y + dy[i] >= 0 && y + dy[i] < grid[x].size())
            {

                if(grid[x+dx[i]][y+dy[i]] != 0)
                {
                    bool result = vaildateGrid(x + dx[i], y + dy[i], grid);
                    if(!result)
                    {
                        grid[x][y] = 1;
                        return false;
                    }
                }
            }
        }
        grid[x][y] = 1;
        return true;

    }



    //会不会掉
    bool hitBricks(vector<vector<int>> &grid, int x, int y)
    {
        if(grid[x][y] == 0)
        {
            return true;
        }
        if(x == 0)
        {
            return false;
        }
        bool realResult = this->vaildateGrid(x, y, grid);
        if(realResult)
        {
            grid[x][y] = 0;
            nums ++;
            for(int i=0; i<4; i++)
            {
                if(x + dx[i] >= 0 && x + dx[i] < grid.size() && y + dy[i] >= 0 && y + dy[i] < grid[x].size())
                {
                    if(grid[x+dx[i]][y+dy[i]] != 0)
                    {
                        hitBricks(grid, x+dx[i], y+dy[i]);
                    }
                }
            }
        }
        return realResult;
    }
    //递归 超时了 cache不好加
    vector<int> hitBricks(vector<vector<int>> &grid, vector<vector<int>> &hits)
    {
        vector<int> result(hits.size());
        cache.resize(grid.size());
        for(int i=0; i<grid.size(); i++)
        {
            cache[i].resize(grid[0].size());
        }
        for(int i=0; i<hits.size(); i++)
        {
            nums = 0;
            int x = hits[i][0], y = hits[i][1];
            grid[x][y] = 0;
            for(int j=0; j<4; j++)
            {

                if(x + dx[j] >= 0 && x + dx[j] < grid.size() && y + dy[j] >= 0 && y + dy[j] < grid[x].size())
                {
                    hitBricks(grid, x + dx[j], y + dy[j]);
                }
            }

            result[i] = nums;
        }

        return result;
    }

    void check(vector<vector<int>> &grid, int x, int y, set<int> &noDrop)
    {
        int n = grid.size(), m = grid[0].size();
        if(x < 0 || x >= n || y < 0 || y >= m || grid[x][y] != 1 || noDrop.count(x * m + y))
        {
            return;
        }
        noDrop.insert(x * m + y);
        for(int i=0; i<4; i++)
        {
            check(grid, x + dx[i], y + dy[i], noDrop);
        }
    }
    
    /**
     * @brief 首先我们来想，我们肯定要统计出当前没有掉落的砖头数量，当去掉某个砖头后，我们可以统计当前还连着的砖头数量，
     *        二者做差值就是掉落的砖头数量。那么如何来统计不会掉落的砖头数量呢，由于顶层的砖头时不会掉落的，那么跟顶层相连的所有砖头肯定也不会掉落，
     *        我们就可以使用DFS来遍历，我们可以把不会掉落的砖头位置存入一个HashSet中，这样通过比较不同状态下HashSet中元素的个数，我们就知道掉落了多少砖头。
     *        然后我们再来想一个问题，在没有去除任何砖头的时候，我们DFS查找会遍历所有的砖头，当某个砖头去除后，可能没有连带其他的砖头，
     *        那么如果我们再来遍历一遍所有相连的砖头，相当于又把整个数组搜索了一遍，这样并不是很高效。
     *
     *
     *       我们可以试着换一个思路，如果我们先把要去掉的所有砖头都先去掉，这样我们遍历所有相连的砖头就是最终还剩下的砖头，
     *       然后我们从最后一个砖头开始往回加，每加一个砖头，我们就以这个砖头为起点，DFS遍历其周围相连的砖头，加入HashSet中，
     *       那么只会遍历那些会掉的砖头，那么增加的这些砖头就是会掉的砖头数量了，然后再不停的在增加前面的砖头，直到把hits中所有的砖头都添加回来了，
     *       那么我们也就计算出了每次会掉的砖头的个数。
             我们使用一个HashSet来保存不会掉落的砖头，然后先遍历hits数组，把要掉落的砖头位置的值都减去一个1，
             这里有个需要注意的地方，hits里的掉落位置实际上在grid中不一定有砖头，就是说可能是本身为0的位置，
             那么我们减1后，数组中也可能会有-1，没有太大的影响，不过需要注意一下，这里不能使用 if (grid[i][j]) 来直接判断其是否为1，
             因为非0值-1也会返回true。然后我们对第一行的砖头都调用递归函数，因为顶端的砖头不会掉落，跟顶端的砖头相连的砖头也不会掉落，
             所以要遍历所有相连的砖头，将位置都存入noDrop。然后就是从最后一个位置往前加砖头，先记录noDrop当前的元素个数，然后grid中对应的值自增1，
             之后增加后的值为1了，才说明这块之前是有砖头的，然后我们看其上下左右位置，若有砖头，则对当前位置调用递归，还有一种情况是当前是顶层的话，
             还是要调用递归。递归调用完成后二者的差值再减去1就是掉落的砖头数，减1的原因是去掉的砖头不算掉落的砖头数中
     * @param grid
     * @param hits
     * @return
     */
    vector<int> hitBricks1(vector<vector<int>> &grid, vector<vector<int>> &hits)
    {
        int n = grid.size(), m = grid[0].size(), k = hits.size();
        for(int i=0; i<k; i++)
        {
            int x = hits[i][0], y = hits[i][1];
            grid[x][y] -= 1;
        }
        vector<int> result(hits.size());
        set<int> noDrop;
        for(int i=0; i<m; i++)
        {
            check(grid, 0, i, noDrop);
        }

        for(int i=k-1; i>=0; i--)
        {
            int old = noDrop.size();
            int x = hits[i][0], y = hits[i][1];
            if(++grid[x][y] == 1)
            {
                //这里的x,y直接添加回去是不行的，因为可能它的周围根本就没有砖块，即便加回去了也会掉下去
                int j = 0;
                for(j; j<4; j++)
                {
                    if(x + dx[j] >= 0 && x + dx[j] < grid.size() && y + dy[j] >= 0 && y + dy[j] < grid[x].size() && noDrop.count((x + dx[j]) * m + y + dy[j]))
                    {
                        break;
                    }
                }
                if(j < 4 || x == 0)
                {
                    check(grid, x, y, noDrop);
                    result[i] = noDrop.size() - old - 1;
                }

            }
        }

        return result;
    }


    int find(vector<int> &root, int x)
    {
        return root[x] == -1 ? x : find(root, root[x]);
    }

    /**
     * @brief 并查集
     * @param grid
     * @param hits
     * @return
     */
    vector<int> hitBricks2(vector<vector<int>> &grid, vector<vector<int>> &hits)
    {
        int m = grid.size(), n = grid[0].size();
        vector<int> t(n, 1), root(m * n, -1), count(m * n, 1);
        vector<int> result(hits.size());
        for(int i=0; i<hits.size(); i++)
        {
            int x = hits[i][0], y = hits[i][1];
            grid[x][y] --;
        }

        for(int i=0; i<m; i++)
        {
            for(int j=0; j < n; j++)
            {
                if(grid[i][j] != 1) continue;
                int a = find(root, i * n + j);
                if(j+1 < n && grid[i][j+1] == 1)
                {
                    int b = find(root, i * n + j + 1);
                    if(a != b)
                    {
                        root[b] = a;
                        count[a] += count[b];
                        t[a] = t[b] = (t[a] | t[b]);
                    }
                }

                if(i+1<m && grid[i+1][j] == 1)
                {
                    int b = find(root, (i + 1) * n + j);
                    if(a != b)
                    {
                        root[b] = a;
                        count[a] += count[b];
                        t[a] = t[b] = (t[a] | t[b]);
                    }
                }
            }

        }

        for(int i = hits.size() - 1; i >= 0; i --)
        {
            int x = hits[i][0], y = hits[i][1], cnt = 0;
            if( ++ grid[x][y] != 1) continue;
            int a = find(root, x*n + y);
            for(int j=0; j<4; j++)
            {
                int newX = x + dx[j], newY = y + dy[j];
                if(newX < 0 || newX >= m || newY < 0 || newY >= n || grid[newX][newY] != 1)
                {
                    continue;
                }
                int b = find(root, newX * n + newY);
                if(a != b)
                {
                    root[b] = a;
                    count[a] += count[b];
                    if (!t[b])
                    {
                        cnt += count[b];
                    }

                    t[a] = t[b] = (t[a] | t[b]);
                }

            }

            if(t[a])
            {
                result[i] = cnt;
            }
        }

        return result;

    }



    void run()
    {
        //        vector<vector<int>> grid({{1,1,1,0,1,1,1,1},
        //                                  {1,0,0,0,0,1,1,1},
        //                                  {1,1,1,0,0,0,1,1},
        //                                  {1,1,0,0,0,0,0,0},
        //                                  {1,0,0,0,0,0,0,0},
        //                                  {1,0,0,0,0,0,0,0}}),
        //                hits({{4,6},{3,0},{2,3},{2,6},{4,1},{5,2},{2,1}});

        vector<vector<int>> grid({{1,0,1},{1,1,1}}), hits({{0, 0}, {0, 2},{1, 1}});

        vector<int> result = this->hitBricks1(grid, hits);
        printVector(result);
    }
};





