/**
* @projectName   lintcode-cpp

* @author        yanpf
* @date          2019-06-26
* @brief         移除K位
* @description   给定一个以字符串表示的非负整数，从该数字中移除掉k个数位，让剩余数位组成的数字尽可能小，求可能的最小结果
*
* @example
*                样例1：

*                输入：num = "1432219", k = 3
*                输出："1219"
*                说明：移除数位4, 3, 2后生成了最小的新数字1219。
*                样例2：

*                输入：num = "10200", k = 1
*                输出："200"
*                说明：移除最前面的1之后，剩余数字为200。注意输出结果不能包含前导零。
*                样例3：

*                输入：num = "10", k = 2
*                输出："0"
*                说明：移除了所有数位，最后什么都不剩了，那么就输出0。
* @solution
*/



#include "commonutils.h"

class RemoveKDigits : public CommonUtils
{
public:
    //BUG  469009211437929393647439059079 这种前面挂0的无效
    string removeKdigits_bug(string &num, int k)
    {
        //        if(num.size() == k)
        //        {
        //            return "0";
        //        }
        vector<bool> remove(num.size(), false);
        while(k > 0)
        {
            bool flag = false;
            for(int i=0; i<num.size() - 1; i++)
            {
                if(remove[i])
                {
                    continue;
                }
                int j = i + 1;
                while(remove[j] && j < num.size())
                {
                    j ++;
                }
                if(j >= num.size() || num[i] > num[j])
                {
                    remove[i] = true;
                    k --;
                    flag = true;
                    if(k == 0)
                    {
                        break;
                    }
                }
            }

            if(!flag)
            {
                break;
            }
        }

        for(int i=remove.size() - 1; i >= 0 && k > 0; i--)
        {
            if(!remove[i])
            {
                remove[i] = true;
                k --;
            }
        }

        string result = "";
        for(int i=0; i<num.size(); i++)
        {
            if(!remove[i] && (num[i] != '0' || (num[i] == '0' && result != "")))
            {
                result.push_back(num[i]);
            }
        }

        return result == "" ?  "0" : result;

    }

    string removeKdigits(string &num, int k)
    {
        while(k > 0)
        {
            for(int i=0; i<num.size(); i++)
            {
                if(i+1 < num.size() && num[i] > num[i+1])
                {
                    num = num.substr(0, i) + num.substr(i+1, num.size() - i - 1);
                    k --;
                    break;
                }
                else if(i == num.size() - 1)
                {
                    num = num.substr(0, i);
                    k --;
                }
            }
        }

        string res = "";
        for(int i=0; i<num.size(); i++)
        {
            if(num[i] == '0' && res == "")
            {
                continue;
            }

            res.push_back(num[i]);
        }

        return res == "" ? "0" : res;
    }

    string removeKdigits2(string &num, int k)
    {
        for(int i=0; i < num.length() && k > 0; i++)
        {
            if(i >= 0 && i + 1 < num.length() && num[i] > num[i+1])
            {
                num = num.substr(0, i) + num.substr(i+1, num.length() - i - 1);
                k --;
                //因为第i个元素被移除了，需要比较第i-1和第i+1个元素
                i = i - 2;
                if(i < 0)
                {
                    i = -1;
                }
            }
        }

        if(k > 0)
        {
            num = num.substr(0, num.size() - k);
        }
        string res = "";
        for(int i=0; i<num.size(); i++)
        {
            if(num[i] == '0' && res == "")
            {
                continue;
            }

            res.push_back(num[i]);
        }

        return res == "" ? "0" : res;

    }

    /**
      * @brief 单调栈
      * @param num
      * @param k
      * @return
      */
    string removeKdigits3(string &num, int k)
    {
        stack<char> s;
        int i=0;
        for(i=0; i<num.size() && k > 0; i++)
        {
            while(!s.empty() && s.top() > num[i] && k > 0)
            {
                s.pop();
                k --;
            }
            s.push(num[i]);
        }
        while(i < num.size())
        {
            s.push(num[i]);
            i ++;
        }
        while(k > 0)
        {
            s.pop();
            k --;
        }
        string res = "";
        while(!s.empty())
        {
            res.push_back(s.top());
            s.pop();
        }
        string result = "";
        for(int i=res.length() - 1; i>=0; i--)
        {
            if(result == "" && res[i] == '0')
            {
                continue;
            }

            result.push_back(res[i]);
        }

        return result == "" ? "0" : result;
    }

    /**
     * @brief 思想和单调栈类型，只是用快慢指针实现的
     * @param num
     * @param k
     * @return
     */
    string removeKdigits4(string &num, int k)
    {
        char nums[num.length()];
        for(int i=0; i<num.size(); i++)
        {
            nums[i] = num[i];
        }
        int index = 0, current = 0;
        while(current < num.size() && k > 0)
        {
            while(index != 0 && k > 0 && nums[index - 1] > nums[current])
            {
                k --;
                index --;
            }
            nums[index ++] = nums[current ++];
        }

        while(current < num.size())
        {
            nums[index ++] = nums[current ++];
        }

        index = index - k;
        current = 0;
        while(nums[current] == '0')
        {
            current ++;
        }

        string res = "";
        while(current < index)
        {
            res += nums[current];
            current ++;
        }

        return res == "" ? "0" : res;
    }

    void run(){
        string num = "1234567890";
        int k = 4;
        string result = this->removeKdigits4(num, k);
        cout<<result<<endl;
    }
};


