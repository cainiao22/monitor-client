/**
* @projectName   lintcode-cpp

* @author        yanpf
* @date          2019-07-01
* @brief         将表达式转换为逆波兰表达式
* @description   给定一个字符串数组，它代表一个表达式，返回该表达式的逆波兰表达式。（去掉括号）
*
* @example
*                样例 1:
*
*                输入: ["3", "-", "4", "+", "5"]
*                输出: ["3", "4", "-", "5", "+"]
*                解释: 3 - 4 + 5 = -1 + 5 = 4
*                    3 4 - 5 + = -1 5 + = 4
*                样例 2:

*                输入: ["(", "5", "-", "6", ")", "*", "7"]
*                输出: ["5","6","-","7","*"]
*                解释: (5 - 6) * 7 = -1 * 7 = -7
*                    5 6 - 7 * = -1 7 * = -7
* @solution
*/


#include "commonutils.h"


class ConvertExpressionToReversePolish : public CommonUtils
{
public:

    void helper(stack<string> & numbers, stack<string> & operators, vector<string> & result)
    {
        string n1 = numbers.top();
        numbers.pop();
        string n2 = numbers.top();
        numbers.pop();
        string opera = operators.top();
        operators.pop();
        if(n2 != " ")
        {
            result.push_back(n2);
        }
        if(n1 != " ")
        {
            result.push_back(n1);
        }
        result.push_back(opera);
        //BUG 这里应该push的是整个result
        numbers.push(" ");
    }

    vector<string> convertToRPN_bug(vector<string> &expression)
    {
        if(expression.size() <= 2)
        {
            return expression;
        }
        vector<string> result;
        stack<string> numbers, operators;
        for(string item : expression)
        {
            if(item == "+" || item == "-")
            {
                if(operators.empty() || operators.top() == "(")
                {
                    operators.push(item);
                }
                else
                {
                    helper(numbers, operators, result);
                    operators.push(item);
                }
            }
            else if(item == "*" || item == "/")
            {
                if(operators.empty() || operators.top() == "+" || operators.top() == "-" || operators.top() == "(")
                {
                    operators.push(item);
                }
                else
                {
                    helper(numbers, operators, result);
                    operators.push(item);
                }
            }
            else if(item == ")")
            {
                while(!operators.empty())
                {
                    string opera = operators.top();
                    if(opera == "(")
                    {
                        operators.pop();
                        break;
                    }
                    helper(numbers, operators, result);
                }
            }
            else if(item == "("){
                operators.push(item);
            }
            else
            {
                numbers.push(item);
            }
        }

        while(!operators.empty())
        {
            helper(numbers, operators, result);
        }
        return result;
    }

    int getPriority(string opera)
    {
        if(opera == "*" || opera == "/")
        {
            return 5;
        }

        if(opera == "-" || opera == "+")
        {
            return 4;
        }

        if(opera == "(")
        {
            return 10;
        }
        if(opera == ")")
        {
            return 0;
        }

        return 1;
    }


    vector<string> convertToRPN_better(vector<string> &expression)
    {
        vector<string> result;
        stack<string> operators;
        for(string str : expression)
        {
            char item = str[0];
            if(item >= '0' && item <= '9')
            {
                result.push_back(str);
            }
            else if(item == ')')
            {
                while(operators.top() != "(")
                {
                    result.push_back(operators.top());
                    operators.pop();
                }
                operators.pop();
            }
            else if(item == '(')
            {
                operators.push(str);
            }
            else
            {
                int priority = getPriority(str);
                while(!operators.empty() && operators.top() != "(" && getPriority(operators.top()) >= priority)
                {
                    result.push_back(operators.top());
                    operators.pop();
                }
                operators.push(str);
            }
        }

        while(!operators.empty())
        {
            result.push_back(operators.top());
            operators.pop();
        }


        return result;
    }

    int getWeight(string exp, int base)
    {
        if(exp == "+" || exp == "-")
        {
            return 1 + base;
        }
        if(exp == "*" || exp == "/")
        {
            return 2 + base;
        }
        //numbers
        return INF;
    }

    //使用二叉树的方式实现
    vector<string> convertToRPN_better2(vector<string> &expression)
    {
        int base = 0;
        stack<ExpressionTreeNode*> s;
        vector<string> result;
        for(string exp : expression)
        {
            if(exp == "(")
            {
                base += 10;
                continue;
            }
            if(exp == ")")
            {
                base -= 10;
            }
            ExpressionTreeNode* right = new ExpressionTreeNode(getWeight(exp, base), exp);
            while(!s.empty())
            {
                ExpressionTreeNode* nodeNow = s.top();
                s.pop();
                if(nodeNow->val >= right->val)
                {
                    if(s.empty())
                    {
                        right->left = nodeNow;
                    }
                    else
                    {
                        ExpressionTreeNode* left = s.top();
                        if(left->val >= right->val)
                        {
                            left->right = nodeNow;
                        }
                        else
                        {
                            right->left = nodeNow;
                        }
                    }
                }
                else
                {
                    break;
                }
            }

            s.push(right);
        }

        return result;
    }

    void run()
    {
        vector<string> expression({"1","+","(","4","+","5", ")"});
        vector<string> result = this->convertToRPN_better2(expression);
        printVector(result);
    }
};

int main()
{
    ConvertExpressionToReversePolish a;
    a.run();
    return 0;
}



