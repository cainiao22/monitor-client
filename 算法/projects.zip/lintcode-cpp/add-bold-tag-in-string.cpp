/**
* @projectName   lintcode-cpp

* @author        yanpf
* @date          2019-06-21
* @brief         Add Bold Tag in String
* @description   给定一个字符串s和一个字符串列表dict，你需要添加一对封闭的粗体标记 <b> 和 </b> 来包装dict中存在的s中的子串。
*                如果两个这样的子串重叠，则需要通过一对封闭的粗体标记将它们包装在一起。
*                此外，如果由粗体标记包装的两个子字符串是连续的，则需要将它们组合在一起。
*
* @example       样例
                 输入:
                 s = "abcxyz123"
                 dict = ["abc","123"]
                 输出:
                 "<b>abc</b>xyz<b>123</b>"
                 输入:
                 s = "aaabbcc"
                 dict = ["aaa","aab","bc"]
                 输出:
                 "<b>aaabbc</b>c"
* @solution
*/


#include "commonutils.h"


class AddBoldTagInStr : public CommonUtils
{
public:
    string addBoldTag(string &s, vector<string> &dict)
    {
        //这个记录的是最远长度
        int end = 0;
        vector<bool> bold(s.size(), false);
        for(int i=0; i<s.size(); i++)
        {
            //这个方式比直接i~j遍历要优化的多
            for(string dic : dict)
            {
                int len = dic.size();
                if(s[i] == dic[0] && s.substr(i, len) == dic)
                {
                    end = max(end, i + len);
                }
            }
            //只要i在最远长度以内，它就包含在<b>中
            bold[i] = end > i;
        }

        string res = "";
        for(int i=0; i<s.size(); i++)
        {
           if(!bold[i])
           {
               res.push_back(s[i]);
           }
           else
           {
               int j=i;
               while(j < s.size() && bold[j])
               {
                   j++;
               }

               res = res + "<b>" + s.substr(i, j - i) + "</b>";
               //因为后面有i++
               i = j - 1;
           }

        }

        return res;
    }

    string addBoldTag2(string &s, vector<string> &dict)
    {
        vector<bool> bold(s.size(), false);
        int end = 0;
        for(int i=0; i<s.size(); i++)
        {
            //这个方式比直接i~j遍历要优化的多
            for(string dic : dict)
            {
                int len = dic.size();
                if(s[i] == dic[0] && s.substr(i, len) == dic)
                {
                    end = max(end, i + len);
                }
            }
            //只要i在最远长度以内，它就包含在<b>中
            bold[i] = end > i;
        }
        string res = "";
        for(int i=0; i<s.size(); i++)
        {
            if((bold[i] && i == 0) || (bold[i] && i - 1 >= 0 && !bold[i-1]))
            {
                res += "<b>";
            }

            res += s[i];

            if((bold[i] && i == s.size() - 1) || (bold[i] && i + 1 < s.size() && !bold[i+1]))
            {
                res += "</b>";
            }
        }

        return res;
    }

    void run()
    {
        string s = "aaabbcc";
        vector<string> dict({"aaa","aab","bc"});
        string result = this->addBoldTag2(s, dict);
        cout<<result<<endl;
    }
};


