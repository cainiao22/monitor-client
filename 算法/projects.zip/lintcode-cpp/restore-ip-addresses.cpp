/**
* @projectName   lintcode-cpp

* @author        yanpf
* @date          2019-06-13
* @brief         恢复IP地址
* @description   给一个由数字组成的字符串。求出其可能恢复为的所有IP地址。
                 (你的任务就是往这段字符串中添加三个点, 使它成为一个合法的IP地址. 返回所有可能的IP地址.)
* @example
*               样例 1:
*
*               输入: "25525511135"
*               输出: ["255.255.11.135", "255.255.111.35"]
*               解释: ["255.255.111.35", "255.255.11.135"] 同样可以.
*               样例 2:
*
*               输入: "1116512311"
*               输出: ["11.165.123.11","111.65.123.11"]
* @solution     又是递归。。。。
*/


#include "commonutils.h"


class RestoreIpAddress : public CommonUtils
{
public:

    vector<string> result;

    void helper(string &s, int index, int count, string &item)
    {
        if(count == 0)
        {
            if(s.length() > index && s.length() - index <= 3)
            {
                string temp = s.substr(index, s.length() - 1);
                if(temp.size() > 1 && temp.at(0) == '0')
                {
                    return;
                }
                if(stoi(temp) >= 256){
                    return;
                }
                string res = item + temp;
                result.push_back(res);
            }
            return;
        }
        else if(s.length() <= index)
        {
           return;
        }
        for(int i=index; i<index+3; i++){
            string temp = s.substr(index, i - index + 1);
            if(temp.size() > 1 && temp.at(0) == '0')
            {
                continue;
            }
            if(stoi(temp) >= 256){
                continue;
            }
            item += temp + '.';
            helper(s, i+1, count - 1, item);
            item = item.substr(0, item.length() - temp.length() - 1);
        }
    }

    vector<string> restoreIpAddresses(string &s)
    {
        if(s.size() < 4 || s.size() > 12)
        {
            return result;
        }
        for(int i=1; i<=3; i++){
            string item = s.substr(0, i);
            if(item.size() > 1 && item.at(0) == '0')
            {
                break;
            }
            item = item + ".";
            helper(s, i, 2, item);
        }

        return result;
    }

    void run()
    {
        string s = "1111";
        this->restoreIpAddresses(s);
        printVector(result);
    }
};



