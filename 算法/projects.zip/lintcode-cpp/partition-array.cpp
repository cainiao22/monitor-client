/**
* @projectName   lintcode-cpp

* @author        yanpf
* @date          2019-09-25
* @brief         数组划分
* @description   给出一个整数数组 nums 和一个整数 k。划分数组（即移动数组 nums 中的元素），使得：
                 所有小于k的元素移到左边
                 所有大于等于k的元素移到右边
                 返回数组划分的位置，即数组中第一个位置 i，满足 nums[i] 大于等于 k

* @example       例1:
                 输入:
                 [],9
                 输出:
                 0

                 例2:

                 输入:
                 [3,2,2,1],2
                 输出:1
                 解释:
                 真实的数组为[1,2,2,3].所以返回 1
*
* @solution
*/

#include "commonutils.h"

class PartitionArray : public CommonUtils
{
public:
    int partitionArray(vector<int> &nums, int k)
    {
        if(nums.size() == 0)
        {
            return 0;
        }
        int i=0, j = nums.size() - 1;
        while(i < j)
        {
            while(nums[i] < k && i < j)
            {
                i ++;
            }
            while(nums[j] >= k && i < j)
            {
                j --;
            }

            if(i < j)
            {
                nums[i] = nums[i] ^ nums[j];
                nums[j] = nums[i] ^ nums[j];
                nums[i] = nums[i] ^ nums[j];
                i ++ ;
                j -- ;
            }
        }
        return i ;
    }
    void run()
    {
        vector<int> nums({});
        int k = 9;
        int result = this->partitionArray(nums, k);
        cout<<result<<endl;
    }
};



