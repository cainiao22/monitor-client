/**
* @projectName   lintcode-cpp

* @author        yanpf
* @date          2019-06-28
* @brief         摘要
* @description   给定一个01矩阵，找出矩阵中连续的最长的 1 。这条线可以是水平的，垂直的，对角线的或者反对角线的
* @example
*                样例 1:

*                输入:
*                  [[0,1,1,0],
*                   [0,1,1,0],
*                   [0,0,0,1]]
*                输出: 3
*                解释: (0,1) (1,2) (2,3)
*                样例 2:

*                输入: [[0,0],[1,1]]
*                输出: 2
*
* @solution
*/


#include "commonutils.h"


class LongestLineOfOneInMatrix : public CommonUtils
{
public:
    int longestLine(vector<vector<int>> &M)
    {
        int res = 0;
        if(M.size() == 0)
        {
            return 0;
        }
        int maxLen = M.size() > M[0].size() ? M.size() : M[0].size();
        for(int i=0; i<M.size(); i++)
        {
            for(int j=0; j<M[0].size(); j++)
            {
                if(M[i][j] == 1)
                {
                    if(i == 0 || (i-1 >= 0 && M[i-1][j] != 1))
                    {
                        int k = i;
                        while(k < M.size() && M[k][j] == 1)
                        {
                            k++;
                        }
                        res =max(res, k - i);
                        if(res == maxLen)
                        {
                            return res;
                        }
                    }
                    if(j == 0 || (j - 1 >= 0 && M[i][j-1] != 1))
                    {
                        int k = j;
                        while(k < M[i].size() && M[i][k] == 1)
                        {
                            k++;
                        }
                        res =max(res, k - j);
                        if(res == maxLen)
                        {
                            return res;
                        }
                    }

                    if(i == 0 || j == 0 || (i - 1 >= 0 && j - 1 >= 0 && M[i-1][j-1] != 1))
                    {
                        int ki = i, kj = j;
                        while(ki < M.size() && kj < M[i].size() && M[ki][kj] == 1)
                        {
                            ki ++;
                            kj ++;
                        }

                        res = max(res, ki - i);
                        if(res == maxLen)
                        {
                            return res;
                        }
                    }
                }

            }
        }

        return res;
    }

    /**
     * @brief 动态规划
     * @param M
     * @return
     */
    int longestLineDP(vector<vector<int>> &M)
    {
        if(M.size() == 0)
        {
            return 0;
        }
        //dp[i][j][k] 表示以M[i][j]为结尾在k方向的最大长度
        int dp[M.size()][M[0].size()][3];
        int DIRECTION = 3;
        int dx[3] = {0, -1, -1};
        int dy[3] = {-1, -1, 0};
        int result = 0;
        for(int i=0; i<M.size(); i++)
        {
            for(int j=0; j<M[0].size(); j++)
            {
                for(int k=0; k< DIRECTION; k++)
                {
                    if(M[i][j] == 0)
                    {
                        dp[i][j][k] = 0;
                    }
                    else if(i + dx[k] >= 0 && i + dx[k] < M.size() && j + dy[k] >= 0 && j + dy[k] < M[0].size())
                    {
                        dp[i][j][k] = dp[i+dx[k]][j + dy[k]][k] + 1;
                    }
                    else
                    {
                        dp[i][j][k] = 1;
                    }

                    result = max(result, dp[i][j][k]);
                }
            }
        }

        return result;
    }

    void run()
    {
        vector<vector<int>> matrix({{0,1,1,0},
                                    {0,1,1,0},
                                    {0,0,0,1}});
        cout<< this->longestLineDP(matrix)<<endl;
    }
};



