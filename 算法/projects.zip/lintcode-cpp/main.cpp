#include <QCoreApplication>


int run(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    return a.exec();
}
