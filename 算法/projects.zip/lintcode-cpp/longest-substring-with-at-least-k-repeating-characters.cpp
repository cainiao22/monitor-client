/**
* @projectName   lintcode-cpp

* @author        yanpf
* @date          2019-06-17
* @brief         字符至少出现K次的最长子串
*
* @description   找出给定字符串的最长子串，使得该子串中的每一个字符都出现了至少k次，返回这个子串的长度
* @example
*
*                样例1：
*
*                输入：
*                s = "aaabb", k = 3
*                输出：
*                3
*                解释：
*                最长子串为"aaa"，因为'a'重复了3次。
*                样例2：

*                输入：
*                s = "ababbc", k = 2
*                输出：
*                5
*                解释：
*                最长子串为"ababb"，因为'a'重复了2次，同时'b'重复了3次
* @solution
*/

#include "commonutils.h"

class LongestSubStringWithatLeastKRepeatingCharacters : public CommonUtils
{
public:
    int longestSubstring(string &s, int k)
    {
        map<char, int> m;
        for(char c : s)
        {
            if(m.count(c))
            {
                m[c] = m[c] + 1;
            }
            else
            {
                m[c] = 1;
            }
        }

        int left = 0;
        int longest = 0;
        for(int i=left+1; i<s.size(); i++)
        {
            if(m[s.at(i)] < k)
            {
                if(i - left >= k)
                {
                    string str = s.substr(left, i-left);
                    int sub = this->longestSubstring(str, k);
                    longest = max(longest, sub);
                }
                left = i+1;
            }
        }

        if(left == 0)
        {
            return s.size();
        }
        if(s.size() - left >= k)
        {
            string str = s.substr(left, s.size() - left);
            int sub = this->longestSubstring(str, k);
            longest = max(longest, sub);
        }
        return longest;
    }


    int longestSubstring2(string &s, int k)
    {
        int result = 0;
        for(int i=0; s != "" && i<s.size() - k + 1; i++)
        {
            int mask = 0;
            vector<int> count(26, 0);
            for(int j=i; j<s.size(); j++)
            {
                int index = s.at(j) - 'a';
                count[index] ++;
                if(count[index] < k)
                {
                    mask |= (1 << index);
                }
                else
                {
                    mask &= ~(1 << index);
                }

                if(mask == 0)
                {
                    result = max(result, j - i + 1);
                }

            }
        }

        return result;
    }


    void run()
    {
        string s = "";
        int k = 1;
        int result = this->longestSubstring2(s, k);
        cout<<result<<endl;
    }

};


