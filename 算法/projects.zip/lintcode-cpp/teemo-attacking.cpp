/**
* @projectName   lintcode-cpp

* @author        yanpf
* @date          2019-06-13
* @brief         提莫攻击
*
* @description   在LOL中，有一个叫做“提莫”的英雄，他的攻击能够让敌人艾希进入中毒状态。
*                现在给定提莫的攻击时间点的升序序列，以及每次提莫攻击时的中毒持续时间，输出总的艾希中毒态的时间
* @example       样例 1:
                 样例: [1,4], 2
                 输出: 4
                 解释: 在第1秒开头, 提莫攻击了艾希，艾希立刻中毒。
                 这次中毒持续2秒，直到第2秒末尾。
                 在第4秒开头, 提莫又攻击了艾希, 又让艾希中毒了2秒。.
                 所以最终结果是4.


                 样例 2:
                 输入: [1,2], 2
                 输出: 3
                 解释: 在1秒钟开头,  提莫攻击了艾希，艾希立刻中毒。
                 这次中毒持续2秒，直到第2秒末尾。
                 然而，第2秒初，提莫又攻击了艾希，而艾希还处在中毒态。
                 由于中毒态不会叠加, 所以中毒态会在3秒末停止。
                 所以，最终返回3。
* @solution
*/

#include "commonutils.h"

class TeemoAttacking : public CommonUtils
{
public:
    int findPoisonedDuration(vector<int> &timeSeries, int duration)
    {
        if(timeSeries.size() == 0)
        {
            return 0;
        }
        int sum = 0;
        for(int i=1; i<timeSeries.size(); i++)
        {
            sum += min(timeSeries[i] - timeSeries[i-1], duration);

        }

        sum += duration;
        return sum;
    }

    int findPoisonedDuration2(vector<int> &timeSeries, int duration)
    {
        if(timeSeries.size() == 0)
        {
            return 0;
        }
        int result = 0;
        int start = timeSeries[0], end = timeSeries[0] + duration;

        for(int i=1; i<timeSeries.size(); i++)
        {
            if(end < timeSeries[i])
            {
                result += end - start;
                start = timeSeries[i];
            }
            end = timeSeries[i] + duration;
        }

        result += end - start;
        return result;
    }

    void run()
    {
        vector<int> timeSeries({1, 2});
        int duration = 2;
        int result = this->findPoisonedDuration(timeSeries, duration);
        cout<<result<<endl;
    }
};



















