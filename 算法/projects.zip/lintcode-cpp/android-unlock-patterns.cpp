/**
* @projectName   lintcode-cpp

* @author        yanpf
* @date          2019-06-19
* @brief         Android解锁模式
*
* @description   给定一个Android 3x3锁定屏幕和两个整数m和n,其中1≤m≤n≤9,统计可以解锁Android锁定屏幕所有有效模式的总数,
*                包括最少的m个键和最多n个键。
                 有效模式的规则:
*                每个模式必须连接至少m个键和最多n个键。
*                所有的键都必须是不同的。
*                如果在模式中连接两个连续键的行通过任何其他键，则其他键必须在模式中选择。不允许跳过非选择键。
*                钥匙的顺序很重要。
*
* @example
*                | 1 | 2 | 3 |
*                | 4 | 5 | 6 |
*                | 7 | 8 | 9 |
*                无效移动: 4 - 1 - 3 - 6
*                路径1 - 3通过在模式中没有选择的关键2.
*                无效移动: 4 - 1 - 9 - 2
*                路径1 - 9通过在模式中没有选择的关键9
*                有效移动: 2 - 4 - 1 - 3 - 6
*                路径1 - 3是有效的，因为它通过了模式中选择的关键2。
*                路径1 - 9通过在模式中没有选择的关键9
*                有效移动: 6 - 5 - 4 - 1 - 9 - 2
*                路径1 - 9是有效的，因为它通过了模式中选择的关键5
* @solution
*/


#include "commonutils.h"

#define N  3
class AndroidUnlockPattern : public CommonUtils
{
public:
    int map[N][N];
    stack<int> s;
    int result = 0;
    int dx[8] = {-1, 0, 1, 0, -1, 1, 1, -1};
    int dy[8] = {0, 1, 0, -1, 1, 1, -1, -1};

    int d2x[8] = {-1, -2, -2, -1, 1, 2, 2, 1};
    int d2y[8] = {-2, -1, 1, 2, 2, 1, -1, -2};

    bool validPosition(int x, int y, int i, int k)
    {
        if(x + dx[i] + k * dx[i] < 0
                || x + dx[i] + k * dx[i] >= N
                || y + dy[i] + k * dy[i] < 0
                || y+dy[i] + k * dy[i] >= N
                || map[x+dx[i] + k * dx[i]][y+dy[i] + k * dy[i]] != 0)
        {
            return false;
        }

        for(int j=0; j<k; j++)
        {
            if(map[x+dx[i]+j][y+dy[i]+j] == 0)
            {
                return false;
            }
        }

        return true;
    }

    void dfs(int m, int n)
    {
        if(s.size() >= m && s.size() <= n)
        {
            result ++;
        }

        if(s.size() >= n)
        {
            return;
        }

        int x = s.top() / N, y = s.top() % N;
        for(int k = 0; k<N; k++)
        {
            bool flag1 = false, flag2 = false;
            for(int i=0; i<8; i++)
            {
                if(validPosition(x, y, i, k))
                {
                    s.push((x+dx[i] + k * dx[i]) * N + y + dy[i] + k * dy[i]);
                    map[x+dx[i] + k * dx[i]][y+dy[i] + k * dy[i]] = 1;
                    dfs(m, n);
                    map[x+dx[i] + k * dx[i]][y+dy[i] + k * dy[i]] = 0;
                    s.pop();
                    flag1 = true;
                }
            }

            for(int i=0; i<8; i++)
            {
                if(x+d2x[i] + k * d2x[i] >= 0
                        && x+d2x[i] + k * d2x[i] < N
                        && y+d2y[i] + k * d2y[i] >= 0
                        && y+d2y[i] + k * d2y[i] < N
                        && map[x+d2x[i] + k * d2x[i]][y+d2y[i] + k * d2y[i]] == 0)
                {
                    s.push((x+d2x[i] + k * d2x[i]) * N + y + d2y[i] + k * d2y[i]);
                    map[x+d2x[i] + k * d2x[i]][y+d2y[i] + k * d2y[i]] = 1;
                    dfs(m, n);
                    map[x+d2x[i] + k * d2x[i]][y+d2y[i] + k * d2y[i]] = 0;
                    s.pop();

                    flag2 = true;
                }
            }

            if(!flag1 && !flag2)
            {
                break;
            }
        }


    }

    int numberOfPatterns(int m, int n)
    {
        for(int i=0; i<3; i++)
        {
            for(int j=0; j<3; j++)
            {
                map[i][j] = 0;
            }
        }

        for(int i=0; i<3; i++)
        {
            for(int j=0; j<3; j++)
            {
                s.push(i*N + j);
                map[i][j] = 1;
                dfs(m, n);
                map[i][j] = 0;
                s.pop();
            }
        }
        return result;
    }

    int helper(int num, int len, int res, int m, int n, vector<vector<int>> &jumps, vector<int> &visited)
    {
        s.push(num);
        if(len >= m)
        {
            res ++;
        }
        len ++;
        if(len > n)
        {
            s.pop();
            return res;
        }
        visited[num] = 1;
        for(int i=1; i<10; i++)
        {
            int jump = jumps[num][i];
            if(!visited[i] && (jump == 0 || visited[jump]))
            {
                //res 一直没有减
                res = helper(i, len, res, m, n, jumps, visited);
            }
        }
        visited[num] = 0;
        s.pop();
        return res;
    }


    int numberOfPatterns2(int m, int n)
    {
        vector<int> visited(10, 0);
        vector<vector<int>> jumps(10, vector<int>(10, 0));
        int res = 0;
        jumps[1][3] = jumps[3][1] = 2;
        jumps[4][6] = jumps[6][4] = 5;
        jumps[7][9] = jumps[9][7] = 8;
        jumps[1][7] = jumps[7][1] = 4;
        jumps[2][8] = jumps[8][2] = 5;
        jumps[3][9] = jumps[9][3] = 6;
        jumps[1][9] = jumps[9][1] = jumps[3][7] = jumps[7][3] = 5;
        res += helper(1, 1, 0, m, n, jumps, visited) * 4;
        res += helper(2, 1, 0, m, n, jumps, visited) * 4;
        res += helper(5, 1, 0, m, n, jumps, visited);
        return res;
    }


    int count(int m, int n, int used, int i1, int j1)
    {
        int res = m <= 0;
        //因为在上一个操作中没有做累加，所以这次的i1、j1算到了本次操作中
        if(!n) return 1;
        for(int i=0; i<3; i++)
        {
            for(int j=0; j<3; j++)
            {
                int I = i1 + i, J = j1 + j;
                int used2 = used | (1 << (i*3 + j));
                if(used2 > used && (J % 2 || I % 2 || (J % 2 == 0 && I % 2 == 0 && (1 << (I/2) * 3 + J / 2) & used2)))
                {
                    res += count(m-1, n-1, used2, i, j);
                }
                else
                {
                    cout<<"i:"<<i<<", j:"<<j<<endl;
                }
            }
        }

        return res;
    }

    int numberOfPatterns3(int m, int n)
    {
        //后面俩数的作用很大，不是每个都能放这里，大概是为了保证for循环里面的if能够永远成立才能放进去
        return count(m, n, 0, 1, 1);
    }


    void run()
    {
        int m = 1, n = 1;
        int result1 = this->numberOfPatterns2(m, n);
        cout<<endl<<"********************"<<endl;
        int result2 = this->numberOfPatterns3(m, n);
        cout<<endl;
        cout<<result1<<endl;
        cout<<result2<<endl;
    }
};



